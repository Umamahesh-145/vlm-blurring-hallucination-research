ANONYMOUS RESEARCH SUBMISSION PACKAGE

Paper: main.tex
Figures: metrics_comparison.png, pope_random_metrics.png, pope_popular_metrics.png, pope_adversarial_metrics.png
Results: custom_metrics.csv and POPE metrics/summary CSV files

This project evaluates Qwen2.5-VL-3B-Instruct on original images and images processed with Gaussian blur (radius 3), using a custom COCO annotation-derived set and POPE random, popular, and adversarial splits.

ANONYMOUS REVIEW: Author name and institutional affiliation have been removed from main.tex. Please also inspect PDF metadata and repository history before submission. Do not include names, email addresses, institutional identifiers, private paths, or account handles in the submitted manuscript or public repository.

LIMITATIONS / INTEGRITY: Results are descriptive and cover one model and one blur radius. The custom negative labels are derived from COCO annotations and do not prove visual absence. CHAIR was not run. JPEG Q30/Q10 are not part of the completed results in this manuscript. No statistical significance claim is made.

To compile: run pdflatex main.tex twice. Keep spconf.sty and the four PNG figures in the same directory.
